package String;

import java.util.*;

public class Iterning {

    public static void main(String[] args) {
        
        String s1="Hello";
        String s2="Hello";
        System.out.println(s1);
        System.out.println(s2);
        System.out.println("After Changing......");

        s1="Mello";

        System.out.println(s1);
        System.out.println(s2);

    }
    
}
