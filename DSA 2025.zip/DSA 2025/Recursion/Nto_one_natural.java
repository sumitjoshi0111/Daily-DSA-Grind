public class Nto_one_natural{


    public static void print_decreasing(int n){
            //base case
            if(n==1)
            {
                System.out.println(n);
                return;
            }
            //self work
            System.out.print(n+" ");
            // Recursive work
            print_decreasing(n-1);

    }
    public static void main(String arg[]){

        int n=100;
        print_decreasing(n);
    }
}